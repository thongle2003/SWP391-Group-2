package com.evtrading.swp391.dto;

import lombok.Data;

@Data
public class ListingImageDTO {
    private Integer id;
    private String url;
    private Boolean isPrimary;
}
