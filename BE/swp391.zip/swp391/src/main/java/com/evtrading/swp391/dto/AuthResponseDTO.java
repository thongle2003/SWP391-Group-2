package com.evtrading.swp391.dto;

import jakarta.persistence.criteria.CriteriaBuilder.In;

public class AuthResponseDTO {
    private String token;
    private String tokenType = "Bearer ";
    private Integer userID;
    private String username;
    private String email;
    private String role;

    public AuthResponseDTO(String token, Integer userID, String username, String email, String role) {
        this.token = token;
        this.userID = userID;
        this.username = username;
        this.email = email;
        this.role = role;
    }

    // Getters and Setters
    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getTokenType() {
        return tokenType;
    }

    public void setTokenType(String tokenType) {
        this.tokenType = tokenType;
    }

    public Integer getUserID() {
        return userID;
    }

    public void setUserID(Integer userID) {
        this.userID = userID;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }
}
