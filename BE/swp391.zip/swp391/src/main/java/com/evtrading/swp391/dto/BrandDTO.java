package com.evtrading.swp391.dto;

import lombok.Data;

@Data
public class BrandDTO {
    private Integer brandId;
    private String brandName;
}